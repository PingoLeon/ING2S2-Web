
<div class="container" id="background" style="padding : 15px">
    <div class="container" id="main_bloc">
        <div class="row">
            <br><br><br>
            <h1 style="margin:15px">Informations sur l'entreprise</h1>
            <br>
            <?php echo'<p style="margin:15px"> '.$data['Informations'].''; ?></p>
            </p>
        </div>
    </div>
</div>
<br><br><br>
</div>
